def worst_choice
  puts "You stumble around and fall on a knife and die. Good job!"
end
